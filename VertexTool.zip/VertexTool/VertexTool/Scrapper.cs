﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HtmlAgilityPack;
using Newtonsoft.Json;
using System.IO;
using System.Collections.ObjectModel;
using System.Web;
using System.Text.RegularExpressions;


namespace VertexTool
{
    class Scrapper
    {
        private ObservableCollection<MobileModel> _mobileEntries = new ObservableCollection<MobileModel>();
        private ObservableCollection<TabletModel> _tabletEntries = new ObservableCollection<TabletModel>();
        private ObservableCollection<MobileModel4G> _mobile4GEntries = new ObservableCollection<MobileModel4G>();
        public ObservableCollection<MobileModel> MobileEntries
        {
            get { return _mobileEntries; }
            set { _mobileEntries = value; }
        }

        public ObservableCollection<TabletModel> TabletEntries
        {
            get { return _tabletEntries; }
            set { _tabletEntries = value; }
        }

        public ObservableCollection<MobileModel4G> Mobile4GEntries
        {
            get { return _mobile4GEntries; }
            set { _mobile4GEntries = value; }
        }

        /// <summary>
        /// This function is where all the scrapping is done.
        /// Why under one 
        /// </summary>
        /// <param name="page"></param>
        public void ScrapeData(string page)
        {
            var web = new HtmlWeb();
            var doc = web.Load(page);
            //var doc2 = web2.Load(page);

            var entries = new MobileModel();
          

            //Nested IF Else is not the most intelligent line(s) of code but it works...
            //Testing if certain cell is eSim compatible
            if (doc.DocumentNode.InnerHtml.ToString().Contains("eSIM"))
            {
                entries.ESIMCompatible = true;
            }
            //Testing Scrapped data if the SIM Size is Single Sim then set it to Nano-Sim
            if (doc.DocumentNode.InnerHtml.ToString().Contains("Single SIM"))
            {
                entries.SIMSize = "Nano-SIM";
            }
            else if (doc.DocumentNode.InnerHtml.ToString().Contains("Nano-SIM and/or eSIM"))
            {
                entries.SIMSize = "Nano-SIM";
            }
            else if (doc.DocumentNode.InnerHtml.ToString().Contains("Nano-SIM"))
            {
                entries.SIMSize = "Nano-SIM";
            }
            
            //Trim display size output after scrapping.
            if(doc.DocumentNode.InnerHtml.ToString().Contains("Display"))
            {
                string displayTrim = doc.DocumentNode.SelectSingleNode("//td[@data-spec='displaysize']").InnerHtml;
                entries.Display = displayTrim.Remove(11, displayTrim.Length - 12).TrimStart();
            }

            //Testing conditions if the device supports 5G Band. If device does support then display 5G Band.
            //Otherwise, leave the output to be null.
            if (doc.DocumentNode.InnerHtml.ToString().Contains("5G bands"))
            {
                string fiveG = doc.DocumentNode.SelectSingleNode("//td[@data-spec='net5g']").InnerHtml;
                entries._5G = fiveG.ToString();
            }
            else
            {
                entries._5G = null;
            }

            //if(doc.DocumentNode.InnerHtml.ToString().Contains("comment"))
            //{
            //    string versionNum = doc.DocumentNode.SelectSingleNode("//td[@data-spec='comment']").InnerHtml;
            //    entries.Version = versionNum.ToString();
            //}
            //else
            //{
            //    entries.Version = null;
            //}

            //Trim weight output after scrapping
            if (doc.DocumentNode.InnerHtml.ToString().Contains("Weight"))
            {
                string weightTrim = doc.DocumentNode.SelectSingleNode("//td[@data-spec='weight']").InnerHtml;
                entries.Weight = weightTrim.Remove(0, weightTrim.Length - 10).TrimStart();

            }


             //Tablet Scrape
            //Checking if the link contains tablet information or not
            if (doc.DocumentNode.InnerHtml.ToString().Contains("Tab"))
            {
                //Tablet
                var tabletModel = new TabletModel
                {
                    PIMTitle = doc.DocumentNode.SelectSingleNode("//h1[@data-spec='modelname']").InnerText,
                    Version = doc.DocumentNode.SelectSingleNode("//p[@data-spec='comment']").InnerText,
                    //Version = entries.Version,
                    Connectivity = doc.DocumentNode.SelectSingleNode("//a[@data-spec='nettech']").InnerText,
                    _2G = doc.DocumentNode.SelectSingleNode("//td[@data-spec='net2g']").InnerText,
                    _3G = doc.DocumentNode.SelectSingleNode("//td[@data-spec='net3g']").InnerText,
                    _4G = doc.DocumentNode.SelectSingleNode("//td[@data-spec='net4g']").InnerText,
                    _5G = entries._5G,
                    Display = doc.DocumentNode.SelectSingleNode("//td[@data-spec='displaysize']").InnerText.Remove(11, 40).Replace(",", entries.Display),
                    Bluetooth = doc.DocumentNode.SelectSingleNode("//td[@data-spec='bluetooth']").InnerText,
                    Battery = doc.DocumentNode.SelectSingleNode("//td[@data-spec='batdescription1']").InnerText,
                    Processor = doc.DocumentNode.SelectSingleNode("//td[@data-spec='cpu']").InnerText,
                    MaxStorageSize = doc.DocumentNode.SelectSingleNode("//td[@data-spec='memoryslot']").InnerText,
                    RearCamera = doc.DocumentNode.SelectSingleNode("//td[@data-spec='cam1modules']").InnerText.Replace("\r\n", entries.RearCamera),
                    FrontCamera = doc.DocumentNode.SelectSingleNode("//td[@data-spec='cam2modules']").InnerText.Replace("\\", entries.FrontCamera),
                    //Weight = doc.DocumentNode.SelectSingleNode("//td[@data-spec='weight']").InnerText.Remove(0, 6),
                    Weight = entries.Weight.Replace("(", entries.Weight),
                    Dimensions = doc.DocumentNode.SelectSingleNode("//td[@data-spec='dimensions']").InnerText.Remove(0, 21).TrimStart().Replace("(", "").Replace(")", ""),
                    OS = doc.DocumentNode.SelectSingleNode("//td[@data-spec='os']").InnerText,
                    Color = doc.DocumentNode.SelectSingleNode("//td[@data-spec='colors']").InnerText,
                    SIMSize = doc.DocumentNode.SelectSingleNode("//td[@data-spec='sim']").InnerText

                };
                
                string filename = "tabletData.json";
                string jsonString = JsonConvert.SerializeObject(tabletModel, Formatting.Indented);
                File.WriteAllText(filename, jsonString);
                //Console.WriteLine(File.ReadAllText(filename)); //Testing if scrapped data will print in Console
            }

            //Mobile Phone 5G Support
            //JSON Formatting the properties to the specific data entry
            else if (doc.DocumentNode.InnerHtml.ToString().Contains("5g"))
            {
                var mobileModel = new MobileModel
                {

                    //PIMTitle = doc.DocumentNode.SelectSingleNode("//h1[@class='specs-phone-name-title']").InnerText,
                    PIMTitle = doc.DocumentNode.SelectSingleNode("//h1[@data-spec='modelname']").InnerText,
                    Version = doc.DocumentNode.SelectSingleNode("//p[@data-spec='comment']").InnerText,
                    //Version = entries.Version,
                    Connectivity = doc.DocumentNode.SelectSingleNode("//a[@data-spec='nettech']").InnerText,
                    _2G = doc.DocumentNode.SelectSingleNode("//td[@data-spec='net2g']").InnerText,
                    _3G = doc.DocumentNode.SelectSingleNode("//td[@data-spec='net3g']").InnerText,
                    _4G = doc.DocumentNode.SelectSingleNode("//td[@data-spec='net4g']").InnerText,
                    _5G = entries._5G,
                    //Display = doc.DocumentNode.SelectSingleNode("//td[@data-spec='displaysize']").InnerText.Remove(10, 40).Replace(")", entries.Display),
                    Display = entries.Display.Replace(")", "").Replace(",", ""),
                    Bluetooth = doc.DocumentNode.SelectSingleNode("//td[@data-spec='bluetooth']").InnerText,
                    Battery = doc.DocumentNode.SelectSingleNode("//td[@data-spec='batdescription1']").InnerText,
                    Processor = doc.DocumentNode.SelectSingleNode("//td[@data-spec='cpu']").InnerText,
                    MaxStorageSize = doc.DocumentNode.SelectSingleNode("//td[@data-spec='memoryslot']").InnerText,
                    RearCamera = doc.DocumentNode.SelectSingleNode("//td[@data-spec='cam1modules']").InnerText.Replace("\r\n", entries.RearCamera).Replace("\\", entries.RearCamera),
                    FrontCamera = doc.DocumentNode.SelectSingleNode("//td[@data-spec='cam2modules']").InnerText.Replace("\\", entries.FrontCamera).Replace("\\", entries.FrontCamera),                                                                           
                    Weight = entries.Weight.Replace("(", "").Replace(")", ""),
                    Dimensions = doc.DocumentNode.SelectSingleNode("//td[@data-spec='dimensions']").InnerText.Remove(0, 21).TrimStart().Replace("(", "").Replace(")", ""),
                    OS = doc.DocumentNode.SelectSingleNode("//td[@data-spec='os']").InnerText,
                    Color = doc.DocumentNode.SelectSingleNode("//td[@data-spec='colors']").InnerText,
                    SIMSize = entries.SIMSize,
                    ESIMCompatible = entries.ESIMCompatible

                };
                //Writing to a JSON File
                string filename = "mobileData.json";
                string jsonString = JsonConvert.SerializeObject(mobileModel, Formatting.Indented);
                File.WriteAllText(filename, jsonString);
            }//end of IF (5G Support)
          
        }
         

    }

}