﻿namespace ClientMetro
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.exit_btn = new System.Windows.Forms.Button();
            this.cstm_btn = new System.Windows.Forms.Button();
            this.ctzn_btn = new System.Windows.Forms.Button();
            this.std_btn = new System.Windows.Forms.Button();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.panel1);
            this.flowLayoutPanel1.Controls.Add(this.button5);
            this.flowLayoutPanel1.Controls.Add(this.button6);
            this.flowLayoutPanel1.Controls.Add(this.button7);
            this.flowLayoutPanel1.Controls.Add(this.button8);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1016, 73);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gold;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 70);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(62, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 50);
            this.label1.TabIndex = 0;
            this.label1.Text = " IMA\r\nCLIENT\r\n";
            // 
            // button5
            // 
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button5.Location = new System.Drawing.Point(209, 3);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(176, 56);
            this.button5.TabIndex = 3;
            this.button5.Text = "HOME";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button6.Location = new System.Drawing.Point(391, 3);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(176, 56);
            this.button6.TabIndex = 4;
            this.button6.Text = "N/A";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button7.Location = new System.Drawing.Point(573, 3);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(176, 56);
            this.button7.TabIndex = 5;
            this.button7.Text = "N/A";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button8.Location = new System.Drawing.Point(755, 3);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(176, 56);
            this.button8.TabIndex = 6;
            this.button8.Text = "N/A";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.exit_btn);
            this.panel2.Controls.Add(this.cstm_btn);
            this.panel2.Controls.Add(this.ctzn_btn);
            this.panel2.Controls.Add(this.std_btn);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 73);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 608);
            this.panel2.TabIndex = 1;
            // 
            // exit_btn
            // 
            this.exit_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.exit_btn.FlatAppearance.BorderSize = 0;
            this.exit_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exit_btn.ForeColor = System.Drawing.Color.White;
            this.exit_btn.Image = global::ClientMetro.Properties.Resources.exit;
            this.exit_btn.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.exit_btn.Location = new System.Drawing.Point(3, 529);
            this.exit_btn.Name = "exit_btn";
            this.exit_btn.Size = new System.Drawing.Size(191, 76);
            this.exit_btn.TabIndex = 3;
            this.exit_btn.Text = "Exit";
            this.exit_btn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.exit_btn.UseVisualStyleBackColor = true;
            this.exit_btn.Click += new System.EventHandler(this.Exit_btn_Click);
            // 
            // cstm_btn
            // 
            this.cstm_btn.FlatAppearance.BorderSize = 0;
            this.cstm_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cstm_btn.ForeColor = System.Drawing.Color.White;
            this.cstm_btn.Image = global::ClientMetro.Properties.Resources.custom;
            this.cstm_btn.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.cstm_btn.Location = new System.Drawing.Point(6, 294);
            this.cstm_btn.Name = "cstm_btn";
            this.cstm_btn.Size = new System.Drawing.Size(191, 76);
            this.cstm_btn.TabIndex = 2;
            this.cstm_btn.Text = "Custom Solutions";
            this.cstm_btn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.cstm_btn.UseVisualStyleBackColor = true;
            this.cstm_btn.Click += new System.EventHandler(this.Cstm_btn_Click);
            // 
            // ctzn_btn
            // 
            this.ctzn_btn.FlatAppearance.BorderSize = 0;
            this.ctzn_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ctzn_btn.ForeColor = System.Drawing.Color.White;
            this.ctzn_btn.Image = global::ClientMetro.Properties.Resources.CNC;
            this.ctzn_btn.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ctzn_btn.Location = new System.Drawing.Point(3, 168);
            this.ctzn_btn.Name = "ctzn_btn";
            this.ctzn_btn.Size = new System.Drawing.Size(191, 76);
            this.ctzn_btn.TabIndex = 1;
            this.ctzn_btn.Text = "Citizen";
            this.ctzn_btn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ctzn_btn.UseVisualStyleBackColor = true;
            this.ctzn_btn.Click += new System.EventHandler(this.Ctzn_btn_Click);
            // 
            // std_btn
            // 
            this.std_btn.FlatAppearance.BorderSize = 0;
            this.std_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.std_btn.ForeColor = System.Drawing.Color.White;
            this.std_btn.Image = global::ClientMetro.Properties.Resources.CNC;
            this.std_btn.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.std_btn.Location = new System.Drawing.Point(3, 48);
            this.std_btn.Name = "std_btn";
            this.std_btn.Size = new System.Drawing.Size(194, 76);
            this.std_btn.TabIndex = 0;
            this.std_btn.Text = "Standard";
            this.std_btn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.std_btn.UseVisualStyleBackColor = true;
            this.std_btn.Click += new System.EventHandler(this.Std_btn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.ClientSize = new System.Drawing.Size(1016, 681);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button exit_btn;
        private System.Windows.Forms.Button cstm_btn;
        private System.Windows.Forms.Button ctzn_btn;
        private System.Windows.Forms.Button std_btn;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
    }
}

