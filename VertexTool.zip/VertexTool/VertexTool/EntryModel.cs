﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VertexTool
{

    /// <summary>
    /// MobileModel properties for the specific members to be scrapped.
    /// These are the properties for phones with bands that have 5G 
    /// </summary>
    class MobileModel
    {
        public virtual string PIMTitle { get; set; }
        public virtual string Version { get; set; }
        public virtual string Connectivity { get; set; }
        public virtual string _2G { get; set; }
        public virtual string _3G { get; set; }
        public virtual string _4G { get; set; }
        public virtual string _5G { get; set; }
        public virtual string Display { get; set; } 
        public virtual string Bluetooth { get; set; }
        public virtual string Battery { get; set; }
        public virtual string Processor { get; set; }
        public virtual string MaxStorageSize { get; set; }
        public virtual string RearCamera { get; set; }
        public virtual string FrontCamera { get; set; }
        public virtual string Weight { get; set; }
        public virtual string Dimensions { get; set; }
        public virtual string OS { get; set; }
        public virtual string Color { get; set; }
        public virtual string SIMSize { get; set; }
        public virtual bool ESIMCompatible { get; set; }
    }

 /// <summary>
 ///  These are the properties for phones with bands that only goes up 4G
 /// </summary>
    class MobileModel4G
    {
        public virtual string PIMTitle { get; set; }
        public virtual string Version { get; set; }
        public virtual string Connectivity { get; set; }
        public virtual string _2G { get; set; }
        public virtual string _3G { get; set; }
        public virtual string _4G { get; set; }
        public virtual string _5G { get; set; }
        public virtual string Display { get; set; }
        public virtual string Bluetooth { get; set; }
        public virtual string Battery { get; set; }
        public virtual string Processor { get; set; }
        public virtual string MaxStorageSize { get; set; }
        public virtual string RearCamera { get; set; }
        public virtual string FrontCamera { get; set; }
        public virtual string Weight { get; set; }
        public virtual string Dimensions { get; set; }
        public virtual string OS { get; set; }
        public virtual string Color { get; set; }
        public virtual string SIMSize { get; set; }
        public virtual bool ESIMCompatible { get; set; }
 
    }
    


    /// <summary>
    /// Tablet Properties
    /// </summary>
    class TabletModel
    {
        public virtual string PIMTitle { get; set; }
        public virtual string Version { get; set; }
        public virtual string Connectivity { get; set; }
        public virtual string _2G { get; set; }
        public virtual string _3G { get; set; }
        public virtual string _4G { get; set; }
        public virtual string _5G {get;set;}
        public virtual string Display { get; set; }
        public virtual string Bluetooth { get; set; }
        public virtual string Battery { get; set; }
        public virtual string Processor { get; set; }
        public virtual string MaxStorageSize { get; set; }
        public virtual string FrontCamera { get; set; }
        public virtual string RearCamera { get; set; }
        public virtual string Weight { get; set; }
        public virtual string Dimensions { get; set; }
        public virtual string OS { get; set; }
        public virtual string Color { get; set; }
        public virtual string SIMSize { get; set; }

    }



}
