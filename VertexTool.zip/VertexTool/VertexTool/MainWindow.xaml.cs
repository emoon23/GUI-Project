﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using Microsoft.Win32;
using Newtonsoft.Json.Linq;
using System.Text.RegularExpressions;

namespace VertexTool
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Scrapper scrapper;
        
        public MainWindow()
        {
            InitializeComponent();
            scrapper = new Scrapper();
            DataContext = scrapper;

        }


     
        //This is to allow the user to freely move the application around
        private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {

                DragMove();

            }
        }

        //Scrape Button
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            scrapper.ScrapeData(txtEditor.Text);
       
            if (scrapper != null)
            {

                var saveFileDialog = new SaveFileDialog();
                saveFileDialog.InitialDirectory = @"C:\";
                saveFileDialog.Title = "Save Json Files";
                saveFileDialog.CheckFileExists = true;
                saveFileDialog.CheckPathExists = true;
                saveFileDialog.DefaultExt =".json";
                saveFileDialog.Filter = "*.json";
                saveFileDialog.FilterIndex = 2;
                saveFileDialog.RestoreDirectory = true;
                saveFileDialog.FileName = "";

                Nullable<bool> result = saveFileDialog.ShowDialog();

                Console.WriteLine("FileName: " + saveFileDialog.FileName);

                MessageBox.Show("Extraction Complete!");
                
                //MobileModel mobile = JsonConvert.DeserializeObject<MobileModel>(jsonFile);
                //DataContext = mobile;
                //var saveFileDialog = new SaveFileDialog();
                //saveFileDialog.FileName = "";
                //saveFileDialog.DefaultExt = ".json";
                //saveFileDialog.Filter = "File (*.json) | *.json";

                //MessageBox.Show("Extraction Complete!");
                //string jsonFile = File.ReadAllText("mobileData.json");
                //string jsonFile2 = File.ReadAllText("tabletData.json");
                //MobileModel mobile = JsonConvert.DeserializeObject<MobileModel>(jsonFile);
                //TabletModel tablet = JsonConvert.DeserializeObject<TabletModel>(jsonFile);
                //DataContext = mobile;
                //DataContext = tablet;
            }
            else
            {
                MessageBox.Show("Cannot scrape without link!");

            }

        }

        //Exit Application Button
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }


        //Load Json Data
        private void LoadData()
        {
            string jsonFile = File.ReadAllText("mobileData.json");

            MobileModel mobile = JsonConvert.DeserializeObject<MobileModel>(jsonFile);
            DataContext = mobile;
        }
        
        private void Connection_Click(object sender, RoutedEventArgs e)
        {
            
            //Initiate Connection string to NetSuite
            try
            {

                //scrapper.ScrapeData(txtEditor.Text);

                //Read json file that was created
                //Setting to the bin folder for now..
                //TODO: This cannot be hard coded! 11/19/21
                StreamReader readJson = new StreamReader(@"C:\Users\e.moon\Documents\QuickApps\VertexTool\VertexTool\bin\Debug\mobileData.json");
                string jsonString = readJson.ReadToEnd();

                //Parse the Json File
               
                //dynamic obj = JsonConvert.DeserializeObject<MobileModel>(jsonString);
                ////string pimTitle = obj.PIMTitle;
                //string version = obj.Version;

                //Testing to see if this will be able to grab the PIM Title from the JSON
                //Console.WriteLine(string.Concat("", obj.PIMTitle));
                ////Console.WriteLine(pimTitle);

                string ConString = ConfigurationManager.ConnectionStrings["conString"].ConnectionString;
                string CmdString = string.Empty;


                using (SqlConnection sqlconn = new SqlConnection(ConString))
                {

                    
                    //Check if the json contains a valid JSON
         
                    dynamic obj2 = JsonConvert.DeserializeObject<MobileModel>(jsonString);
                    //string version2 = obj2.Version;
                    var version = obj2.@Version;


                    Match match = Regex.Match(version, @"\w\d+"); //This will get the version number!!
                    if(match.Success)
                    {
                        // string key = match.Groups[1].Value;
                        //key.ToString();
                        match.ToString();
                        Console.WriteLine(match);
                    }
                    //var match = rgx.Match(CmdString);
                    //DO NOT DELETE!
                    // CmdString = "Select FULL_NAME , ITEM_ID, ITEM_TYPE_ID from items Where TYPE_NAME = 'Inventory Item' AND FULL_NAME NOT LIKE '%DNU' AND [3PL_ITEM] != 'T' AND ITEM_TYPE_ID IN ('25')";

                    //LINQ
                    
                    CmdString = "SELECT FULL_NAME, ITEM_ID, ITEM_TYPE_ID from items WHERE TYPE_NAME = 'Inventory Item' AND FULL_NAME NOT LIKE '%DNU' AND [3PL_ITEM] != 'T' AND ITEM_TYPE_ID IN ('25')";

                   // var matchingVer = from s in CmdString where match select s;
                     

                    //CmdString = "Select FULL_NAME, ITEM_ID, ITEM_TYPE_ID from items Where TYPE_NAME = 'Inventory Item' AND FULL_NAME LIKE '%Version%' AND FULL_NAME NOT LIKE '%DNU' AND [3PL_ITEM] != 'T' AND ITEM_TYPE_ID in ('25')";
                    //CmdString = "";
                    SqlCommand cmd = new SqlCommand(CmdString, sqlconn);
                    cmd.Parameters.Add(@"Version", SqlDbType.VarChar, 50).Value = match.Groups[1].Value;
                    cmd.CommandType = CommandType.Text;
                    sqlconn.Open();
                    MessageBox.Show("Connected!");
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable("Items");   
                    sda.Fill(dt);
                    dataGrid1.ItemsSource = dt.DefaultView;
                    cmd.ExecuteNonQuery();

                    //Color Binding Combobox
                   

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to make connection", ex.Message);
            }
        }
       

      
        //Creating a new button that communicates with the REST API

        //JSON Mapping Button
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            //Later on add dialog box for user to import json file(?) <-- makes sense
            OpenFileDialog openFDialog = new OpenFileDialog();
            if(openFDialog.ShowDialog() == true)
            {

                //This needs to change
                string path = @"C:\Users\e.moon\Documents\QuickApps\VertexTool\VertexTool\bin\Debug\mobileData.json";
            
                if(File.Exists(path))
                {
                    Console.WriteLine("File Exists...");
                }
                else
                {
                    Console.WriteLine("File does not exists!");
                }
             

            }

        }

        //DataGrid1 
        private void dataGrid1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
        }
        



        private void txtEditor_TextChanged(object sender, TextChangedEventArgs e)
        {

            //Pattern Matching in SQL with GSMArena url
            

        }


    }

    //Color List Class for the ComboBox
    public class ColorList : List<string>
    {
        public ColorList()
        {
            Add("Black");
            Add("Blue");
            Add("Gold");
            Add("Gray");
            Add("Green");
            Add("Multi");
            Add("Orange");
            Add("Pink");
            Add("Purple");
            Add("Red");
            Add("Silver");
            Add("White");
            Add("Yellow");
        }
    }


}
