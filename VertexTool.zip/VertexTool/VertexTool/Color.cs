﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VertexTool
{
    class Color
    {


        public Colors PhoneColor {get;set;}


    }

    public enum Colors { Black, Blue, Gold, Gray, Green, Multi, Orange, Pink, Purple, Red, Silver, White, Yellow};
}
