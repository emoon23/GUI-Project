CLIENT METRO

This is a prototype client based program. The purpose is to hopefully have users go through a graphical experience
when going through software solutions developed by MEAU developers (i.e. IMA Standard, IMA Citizen Adapter, & Custom Software Solutions).
Nothing in this early demo is final.